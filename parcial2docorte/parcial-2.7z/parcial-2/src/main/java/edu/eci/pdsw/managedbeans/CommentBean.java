package edu.eci.pdsw.managedbeans;

public class CommentBean {

	public CommentBean() {
		// TODO Auto-generated constructor stub
	}

}
